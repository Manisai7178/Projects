import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import oracle.jdbc.driver.OracleDriver;

@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	final static String url="jdbc:oracle:thin:@localhost:1521:XE";
	final static String user="hr";
	final static String pass="hr";
    Connection con=null;
    PreparedStatement ps=null;
    ResultSet rs=null;
    public SearchServlet()  {
        super();
              
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        response.setContentType("text/html;charset=UTF-8");
       PrintWriter out = response.getWriter();
       String coursetype = request.getParameter("coursetype");
       String city = request.getParameter("city");
       try {
       	Class.forName("oracle.jdbc.driver.OracleDriver");
         con = DriverManager.getConnection(url,user,pass);
           System.out.println("Connection establised");
           String s="select * from college where coursetype=? and city=?";
           ps=con.prepareStatement(s);
           ps.setString(1,coursetype);
           ps.setString(2, city);
           ResultSet rs = ps.executeQuery();
       		
       while (rs.next()==true)
       {
    	   String cid=rs.getString(1);
    	   String cname=rs.getString(2);
    	   coursetype=rs.getString(3);
    	    city=rs.getString(4);
    	   String fees=rs.getString(5);
    	   String pincode=rs.getString(6);
    	   out.println(cid+" "+cname+" "+coursetype+" "+city+" "+fees+" "+pincode+"<br>");
    	   
       }
    }
       catch (SQLException | ClassNotFoundException e)
       {
    	   e.printStackTrace();
       }
    }
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
    	
		doGet(request, response);
	}
}
           
           
          
           
           
           
           
           
    